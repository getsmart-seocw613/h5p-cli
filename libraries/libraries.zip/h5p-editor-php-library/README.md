H5P Editor PHP Library
==========

A general library that is supposed to be used in most PHP implementations of H5P.

## License

All code is licensed under MIT License

Open Sans font is licensed under Apache license, Version 2.0